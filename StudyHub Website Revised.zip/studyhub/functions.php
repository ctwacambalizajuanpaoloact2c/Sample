<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
session_start();
date_default_timezone_set('Asia/Manila');

function escape(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $page): never
{
    header('Location: ' . $page);
    exit;
}

function token(): string
{
    if (!isset($_SESSION['token'])) {
        $_SESSION['token'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['token'];
}

function valid_token(): bool
{
    return isset($_POST['token'], $_SESSION['token'])
        && is_string($_POST['token'])
        && hash_equals($_SESSION['token'], $_POST['token']);
}

function file_path(): string
{
    return __DIR__ . '/members.php';
}

function read_records($file): array
{
    rewind($file);
    $contents = stream_get_contents($file);
    if ($contents === false || $contents === '') {
        return ['users' => [], 'notes' => []];
    }

    $prefix = "<?php exit; __halt_compiler();\n";
    if (!str_starts_with($contents, $prefix)) {
        throw new RuntimeException('Account storage could not be read.');
    }
    $records = json_decode(substr($contents, strlen($prefix)), true);
    if (!is_array($records)) {
        throw new RuntimeException('Account storage could not be read.');
    }
    if (isset($records['users'], $records['notes']) && is_array($records['users']) && is_array($records['notes'])) {
        return $records;
    }

    $users = [];
    foreach ($records as $email => $old) {
        if (!is_array($old) || !isset($old['name'], $old['email'], $old['password'])) {
            throw new RuntimeException('Account storage could not be read.');
        }
        $id = substr(hash('sha256', (string) $email), 0, 24);
        $users[$id] = [
            'id' => $id,
            'name' => (string) $old['name'],
            'email' => (string) $old['email'],
            'password' => (string) $old['password'],
            'role' => count($users) === 0 ? 'admin' : 'user',
            'created_at' => date('Y-m-d H:i'),
        ];
    }
    return ['users' => $users, 'notes' => []];
}

function read_data(): array
{
    $file = fopen(file_path(), 'c+');
    if ($file === false) {
        throw new RuntimeException('Account storage is unavailable.');
    }
    try {
        if (!flock($file, LOCK_SH)) {
            throw new RuntimeException('Account storage is unavailable.');
        }
        return read_records($file);
    } finally {
        flock($file, LOCK_UN);
        fclose($file);
    }
}

function change_data(callable $change): mixed
{
    $file = fopen(file_path(), 'c+');
    if ($file === false) {
        throw new RuntimeException('Account storage is unavailable.');
    }
    try {
        if (!flock($file, LOCK_EX)) {
            throw new RuntimeException('Account storage is unavailable.');
        }
        $records = read_records($file);
        $result = $change($records);
        $contents = "<?php exit; __halt_compiler();\n" . json_encode($records, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR);
        rewind($file);
        if (!ftruncate($file, 0)) {
            throw new RuntimeException('Account storage could not be saved.');
        }
        $total = strlen($contents);
        for ($written = 0; $written < $total;) {
            $part = fwrite($file, substr($contents, $written));
            if ($part === false || $part === 0) {
                throw new RuntimeException('Account storage could not be saved.');
            }
            $written += $part;
        }
        fflush($file);
        return $result;
    } finally {
        flock($file, LOCK_UN);
        fclose($file);
    }
}

function find_email(array $users, string $email, ?string $except = null): ?array
{
    foreach ($users as $user) {
        if ($user['id'] !== $except && strtolower($user['email']) === strtolower($email)) {
            return $user;
        }
    }
    return null;
}

function register_member(string $name, string $email, string $password, ?string $role = null): bool
{
    return change_data(function (array &$records) use ($name, $email, $password, $role): bool {
        if (find_email($records['users'], $email) !== null) {
            return false;
        }
        $id = bin2hex(random_bytes(12));
        $records['users'][$id] = [
            'id' => $id,
            'name' => $name,
            'email' => $email,
            'password' => password_hash($password, PASSWORD_DEFAULT),
            'role' => $role ?? (count($records['users']) === 0 ? 'admin' : 'user'),
            'created_at' => date('Y-m-d H:i'),
        ];
        return true;
    });
}

function update_member(string $id, string $name, string $email, string $password, ?string $role = null): bool
{
    return change_data(function (array &$records) use ($id, $name, $email, $password, $role): bool {
        if (!isset($records['users'][$id]) || find_email($records['users'], $email, $id) !== null) {
            return false;
        }
        $records['users'][$id]['name'] = $name;
        $records['users'][$id]['email'] = $email;
        if ($password !== '') {
            $records['users'][$id]['password'] = password_hash($password, PASSWORD_DEFAULT);
        }
        if ($role !== null) {
            $records['users'][$id]['role'] = $role;
        }
        return true;
    });
}

function remove_member(string $id, string $actorId): bool
{
    return change_data(function (array &$records) use ($id, $actorId): bool {
        if ($id === $actorId || !isset($records['users'][$id])) {
            return false;
        }
        unset($records['users'][$id]);
        foreach ($records['notes'] as $noteId => $note) {
            if ($note['owner_id'] === $id) {
                unset($records['notes'][$noteId]);
            }
        }
        return true;
    });
}

function current_user(): ?array
{
    if (empty($_SESSION['user_id']) || !is_string($_SESSION['user_id'])) {
        return null;
    }
    $records = read_data();
    return $records['users'][$_SESSION['user_id']] ?? null;
}

function require_login(): array
{
    $user = current_user();
    if ($user === null) {
        unset($_SESSION['user_id']);
        redirect('index.php');
    }
    return $user;
}

function require_admin(): array
{
    $user = require_login();
    if ($user['role'] !== 'admin') {
        http_response_code(403);
        echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Access denied</title><link rel="stylesheet" href="style.css"></head><body class="dashboard-page"><main class="dashboard-content"><h1>Access denied</h1><p>Only administrators can manage users.</p><a class="text-link" href="dashboard.php">Return to dashboard</a></main></body></html>';
        exit;
    }
    return $user;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function show_flash(): void
{
    if (empty($_SESSION['flash'])) {
        return;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    echo '<div class="message ' . escape((string) $flash['type']) . '">' . escape((string) $flash['message']) . '</div>';
}

function valid_account_input(string $name, string $email, string $password, bool $optionalPassword = false): string
{
    if ($name === '' || strlen($name) > 60) {
        return 'Name must be between 1 and 60 characters.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        return 'Enter a valid email address.';
    }
    if ((!$optionalPassword || $password !== '') && (strlen($password) < 6 || strlen($password) > 72)) {
        return 'Password must have 6 to 72 characters.';
    }
    return '';
}

function add_note(string $ownerId, string $title, string $body): void
{
    change_data(function (array &$records) use ($ownerId, $title, $body): void {
        $id = bin2hex(random_bytes(12));
        $now = date('Y-m-d H:i');
        $records['notes'][$id] = [
            'id' => $id,
            'owner_id' => $ownerId,
            'title' => $title,
            'body' => $body,
            'created_at' => $now,
            'updated_at' => $now,
        ];
    });
}

function edit_note(string $id, string $ownerId, string $title, string $body): bool
{
    return change_data(function (array &$records) use ($id, $ownerId, $title, $body): bool {
        if (!isset($records['notes'][$id]) || $records['notes'][$id]['owner_id'] !== $ownerId) {
            return false;
        }
        $records['notes'][$id]['title'] = $title;
        $records['notes'][$id]['body'] = $body;
        $records['notes'][$id]['updated_at'] = date('Y-m-d H:i');
        return true;
    });
}

function remove_note(string $id, string $ownerId): bool
{
    return change_data(function (array &$records) use ($id, $ownerId): bool {
        if (!isset($records['notes'][$id]) || $records['notes'][$id]['owner_id'] !== $ownerId) {
            return false;
        }
        unset($records['notes'][$id]);
        return true;
    });
}

function my_notes(string $ownerId): array
{
    $records = read_data();
    $notes = array_values(array_filter($records['notes'], fn (array $note): bool => $note['owner_id'] === $ownerId));
    usort($notes, fn (array $a, array $b): int => strcmp($b['created_at'], $a['created_at']));
    return $notes;
}

function page_header(string $title, array $user, string $active): void
{
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= escape($title) ?> | StudyHub</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="dashboard-page">
    <header class="topbar">
        <a class="brand" href="dashboard.php"><span class="brand-symbol">S</span> StudyHub</a>
        <div class="header-actions">
            <span class="role-label"><?= escape(ucfirst($user['role'])) ?></span>
            <form class="logout-form" method="post" action="logout.php">
                <input type="hidden" name="token" value="<?= escape(token()) ?>">
                <button class="logout-link" type="submit">Sign out</button>
            </form>
        </div>
    </header>
    <nav class="site-nav" aria-label="Main navigation">
        <a class="<?= $active === 'dashboard' ? 'selected' : '' ?>" href="dashboard.php">Dashboard</a>
        <a class="<?= $active === 'notes' ? 'selected' : '' ?>" href="notes.php">My Notes</a>
        <a class="<?= $active === 'profile' ? 'selected' : '' ?>" href="profile.php">My Profile</a>
        <?php if ($user['role'] === 'admin'): ?>
            <a class="<?= $active === 'admin' ? 'selected' : '' ?>" href="admin.php">Manage Users</a>
        <?php endif; ?>
    </nav>
<?php
}

function page_footer(): void
{
    echo '</body></html>';
}
