<?php
require_once __DIR__ . '/functions.php';
$user = require_login();
$error = '';
$name = $user['name'];
$email = $user['email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');
    $currentPassword = (string) ($_POST['current_password'] ?? '');

    if (!valid_token()) {
        $error = 'Please refresh the page and try again.';
    } elseif (($validation = valid_account_input($name, $email, $password, true)) !== '') {
        $error = $validation;
    } elseif (!password_verify($currentPassword, $user['password'])) {
        $error = 'Enter your current password to save changes.';
    } elseif (!update_member($user['id'], $name, $email, $password)) {
        $error = 'That email address is already registered.';
    } else {
        flash('success', 'Profile updated.');
        redirect('profile.php');
    }
}
page_header('My Profile', $user, 'profile');
?>
<main class="dashboard-content">
    <span class="eyebrow dark">ACCOUNT SETTINGS</span>
    <h1>My Profile</h1>
    <p class="subtitle">Update your name, email, or password.</p>
    <?php show_flash(); ?>
    <?php if ($error !== ''): ?><div class="message error"><?= escape($error) ?></div><?php endif; ?>
    <section class="account-card form-card">
        <h2>Edit your information</h2>
        <form method="post" action="profile.php">
            <input type="hidden" name="token" value="<?= escape(token()) ?>">
            <label for="name">Full name</label>
            <input id="name" name="name" type="text" maxlength="60" value="<?= escape($name) ?>" required>
            <label for="email">Email address</label>
            <input id="email" name="email" type="email" maxlength="150" value="<?= escape($email) ?>" required>
            <label for="password">New password <span class="optional">(optional)</span></label>
            <input id="password" name="password" type="password" minlength="6" placeholder="Leave blank to keep current password" autocomplete="new-password">
            <label for="current_password">Current password</label>
            <input id="current_password" name="current_password" type="password" autocomplete="current-password" required>
            <div class="inline-actions"><button type="submit" class="small-btn">Save profile</button></div>
        </form>
    </section>
</main>
<?php page_footer(); ?>
