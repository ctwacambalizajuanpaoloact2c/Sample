<?php exit; __halt_compiler();
{
    "users": {
        "2b7ac0ff16e7a3011b908c44": {
            "id": "2b7ac0ff16e7a3011b908c44",
            "name": "Test Name",
            "email": "test@gmail.com",
            "password": "$2y$10$dea0vOpCbl2RDtzjx8x.Uu5dAdbGAvPKsM8ijUBoaA7YBkrG4pCdm",
            "role": "admin",
            "created_at": "2026-11-11 23:25"
        }
    },
    "notes": {
        "b64581bcedb0905939b94c6f": {
            "id": "b64581bcedb0905939b94c6f",
            "owner_id": "2b7ac0ff16e7a3011b908c44",
            "title": "Today's Agenda",
            "body": "Revise the program and improve the functionalities.",
            "created_at": "2026-11-11 23:27",
            "updated_at": "2026-11-11 23:27"
        }
    }
}