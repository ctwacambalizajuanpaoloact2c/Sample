<?php
require_once __DIR__ . '/functions.php';
$admin = require_admin();
$error = '';
$name = '';
$email = '';
$role = 'user';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $id = (string) ($_POST['id'] ?? '');
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');
    $role = (string) ($_POST['role'] ?? 'user');

    if (!valid_token()) {
        $error = 'Please refresh the page and try again.';
    } elseif ($action === 'delete') {
        if (remove_member($id, $admin['id'])) {
            flash('success', 'User deleted along with their notes.');
            redirect('admin.php');
        }
        $error = 'You cannot delete your own account.';
    } elseif ($action === 'create' || $action === 'update') {
        if ($role !== 'admin' && $role !== 'user') {
            $error = 'Choose a valid access level.';
        } elseif (($validation = valid_account_input($name, $email, $password, $action === 'update')) !== '') {
            $error = $validation;
        } elseif ($action === 'create') {
            if (register_member($name, $email, $password, $role)) {
                flash('success', 'User created.');
                redirect('admin.php');
            }
            $error = 'That email address is already registered.';
        } elseif ($id === $admin['id'] && $role !== 'admin') {
            $error = 'You cannot remove your own administrator access.';
        } elseif (update_member($id, $name, $email, $password, $role)) {
            flash('success', 'User updated.');
            redirect('admin.php');
        } else {
            $error = 'User not found or email address already registered.';
        }
    } else {
        $error = 'Invalid action.';
    }
}

$records = read_data();
$users = array_values($records['users']);
usort($users, fn (array $a, array $b): int => strcmp($a['name'], $b['name']));
$selected = null;
$mode = isset($_GET['edit']) ? 'edit' : (isset($_GET['delete']) ? 'delete' : 'create');
$id = (string) ($_GET[$mode] ?? '');
if ($mode !== 'create') {
    $selected = $records['users'][$id] ?? null;
    if ($selected === null) {
        flash('error', 'User not found.');
        redirect('admin.php');
    }
}
if ($mode === 'edit' && $error === '') {
    $name = $selected['name'];
    $email = $selected['email'];
    $role = $selected['role'];
}
page_header('Manage Users', $admin, 'admin');
?>
<main class="dashboard-content wide">
    <span class="eyebrow dark">ADMINISTRATOR ONLY</span>
    <h1>Manage Users</h1>
    <p class="subtitle">Create, view, edit, or delete user accounts and control access levels.</p>
    <?php show_flash(); ?>
    <?php if ($error !== ''): ?><div class="message error"><?= escape($error) ?></div><?php endif; ?>

    <section class="account-card form-card">
        <?php if ($mode === 'delete'): ?>
            <h2>Delete user?</h2>
            <p class="muted">This will permanently delete <?= escape($selected['name']) ?> and all of their notes.</p>
            <form method="post" action="admin.php">
                <input type="hidden" name="token" value="<?= escape(token()) ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= escape($selected['id']) ?>">
                <div class="inline-actions"><button type="submit" class="danger-btn" <?= $selected['id'] === $admin['id'] ? 'disabled' : '' ?>>Delete user</button><a href="admin.php" class="secondary-btn">Cancel</a></div>
            </form>
        <?php else: ?>
            <h2><?= $mode === 'edit' ? 'Edit user' : 'Add a user' ?></h2>
            <form method="post" action="<?= $mode === 'edit' ? 'admin.php?edit=' . escape($selected['id']) : 'admin.php' ?>">
                <input type="hidden" name="token" value="<?= escape(token()) ?>">
                <input type="hidden" name="action" value="<?= $mode === 'edit' ? 'update' : 'create' ?>">
                <?php if ($mode === 'edit'): ?><input type="hidden" name="id" value="<?= escape($selected['id']) ?>"><?php endif; ?>
                <div class="two-cols">
                    <div><label for="name">Full name</label><input id="name" name="name" type="text" maxlength="60" value="<?= escape($name) ?>" required></div>
                    <div><label for="email">Email</label><input id="email" name="email" type="email" maxlength="150" value="<?= escape($email) ?>" required></div>
                </div>
                <label for="password">Password <?= $mode === 'edit' ? '(leave blank to keep)' : '' ?></label>
                <input id="password" name="password" type="password" <?= $mode === 'create' ? 'required minlength="6"' : '' ?> autocomplete="new-password" placeholder="<?= $mode === 'edit' ? 'Optional new password' : 'At least 6 characters' ?>">
                <label for="role">Access level</label>
                <select id="role" name="role"><option value="user" <?= $role === 'user' ? 'selected' : '' ?>>User</option><option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Administrator</option></select>
                <div class="inline-actions"><button type="submit" class="small-btn"><?= $mode === 'edit' ? 'Save changes' : 'Create user' ?></button><?php if ($mode === 'edit'): ?><a href="admin.php" class="secondary-btn">Cancel</a><?php endif; ?></div>
            </form>
        <?php endif; ?>
    </section>

    <section class="section-space">
        <div class="section-heading"><h2>Registered users</h2><span class="muted"><?= count($users) ?> total</span></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Name</th><th>Email</th><th>Access</th><th>Actions</th></tr></thead>
                <tbody>
                <?php foreach ($users as $member): ?>
                    <tr>
                        <td><?= escape($member['name']) ?><?= $member['id'] === $admin['id'] ? ' <span class="meta">(you)</span>' : '' ?></td>
                        <td><?= escape($member['email']) ?></td>
                        <td><span class="table-role"><?= escape(ucfirst($member['role'])) ?></span></td>
                        <td class="table-actions"><a class="text-link" href="admin.php?edit=<?= urlencode($member['id']) ?>">Edit</a><?php if ($member['id'] !== $admin['id']): ?><a class="delete-link" href="admin.php?delete=<?= urlencode($member['id']) ?>">Delete</a><?php endif; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>
<?php page_footer(); ?>
