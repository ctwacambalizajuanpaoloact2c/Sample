<?php
require_once __DIR__ . '/functions.php';

if (current_user() !== null) {
    redirect('dashboard.php');
}

$error = '';
$name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');
    $confirmation = (string) ($_POST['confirm_password'] ?? '');

    if (!valid_token()) {
        $error = 'Please refresh the page and try again.';
    } elseif (($validation = valid_account_input($name, $email, $password)) !== '') {
        $error = $validation;
    } elseif ($password !== $confirmation) {
        $error = 'Passwords do not match.';
    } else {
        try {
            if (register_member($name, $email, $password)) {
                redirect('index.php?registered=1');
            }
            $error = 'This email is already registered.';
        } catch (RuntimeException $exception) {
            $error = 'Could not create your account. Check folder permissions.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | StudyHub</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="auth-layout">
        <section class="intro-panel">
            <a class="brand" href="index.php"><span class="brand-symbol">S</span> StudyHub</a>
            <div class="intro-content">
                <span class="eyebrow">START HERE</span>
                <h1>Make room for your next chapter.</h1>
                <p>Create an account and manage your own learning notes.</p>
                <div class="mini-card"><span class="mini-icon">✦</span><span>Small steps. Big progress.</span></div>
            </div>
            <span class="intro-footer">StudyHub © 2026</span>
        </section>
        <section class="form-panel">
            <div class="form-wrap">
                <span class="mobile-brand">StudyHub</span>
                <span class="eyebrow dark">JOIN STUDYHUB</span>
                <h2>Create an account</h2>
                <p class="subtitle">The first account created will be the administrator.</p>
                <?php if ($error !== ''): ?>
                    <div class="message error"><?= escape($error) ?></div>
                <?php endif; ?>
                <form method="post" action="register.php">
                    <input type="hidden" name="token" value="<?= escape(token()) ?>">
                    <label for="name">Full name</label>
                    <input id="name" name="name" type="text" placeholder="Your name" autocomplete="name" maxlength="60" value="<?= escape($name) ?>" required>
                    <label for="email">Email address</label>
                    <input id="email" name="email" type="email" placeholder="you@example.com" autocomplete="email" maxlength="150" value="<?= escape($email) ?>" required>
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password" placeholder="At least 6 characters" autocomplete="new-password" minlength="6" required>
                    <label for="confirm_password">Confirm password</label>
                    <input id="confirm_password" name="confirm_password" type="password" placeholder="Repeat your password" autocomplete="new-password" minlength="6" required>
                    <button type="submit" class="primary-btn">Create account</button>
                </form>
                <p class="form-switch">Already have an account? <a href="index.php">Sign in</a></p>
            </div>
        </section>
    </main>
</body>
</html>
