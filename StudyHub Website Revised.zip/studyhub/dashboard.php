<?php
require_once __DIR__ . '/functions.php';
$user = require_login();
$notes = my_notes($user['id']);
page_header('Dashboard', $user, 'dashboard');
?>
<main class="dashboard-content">
    <span class="eyebrow dark">YOUR DASHBOARD</span>
    <h1>Hello, <?= escape($user['name']) ?>!</h1>
    <p class="subtitle">Welcome back to your StudyHub workspace.</p>
    <?php show_flash(); ?>
    <section class="welcome-card">
        <div class="welcome-icon">✦</div>
        <h2>You're all signed in.</h2>
        <p>You have <?= count($notes) ?> <?= count($notes) === 1 ? 'note' : 'notes' ?> in your workspace. Create one or continue editing your ideas.</p>
        <a href="notes.php" class="small-btn">Go to My Notes</a>
    </section>
    <section class="account-card">
        <h2>Account information</h2>
        <div class="account-row"><span>Name</span><strong><?= escape($user['name']) ?></strong></div>
        <div class="account-row"><span>Email</span><strong><?= escape($user['email']) ?></strong></div>
        <div class="account-row"><span>Access level</span><strong><?= escape(ucfirst($user['role'])) ?></strong></div>
        <div class="card-actions">
            <a class="text-link" href="profile.php">Edit profile</a>
            <?php if ($user['role'] === 'admin'): ?><a class="text-link" href="admin.php">Manage users</a><?php endif; ?>
        </div>
    </section>
</main>
<?php page_footer(); ?>
