<?php
require_once __DIR__ . '/functions.php';

if (current_user() !== null) {
    redirect('dashboard.php');
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');

    if (!valid_token()) {
        $error = 'Please refresh the page and try again.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $error = 'Enter a valid email and password.';
    } else {
        try {
            $records = read_data();
            $member = find_email($records['users'], $email);
            if ($member !== null && password_verify($password, $member['password'])) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = $member['id'];
                redirect('dashboard.php');
            }
            $error = 'Incorrect email or password.';
        } catch (RuntimeException $exception) {
            $error = 'Sign in is unavailable right now.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In | StudyHub</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="auth-layout">
        <section class="intro-panel">
            <a class="brand" href="index.php"><span class="brand-symbol">S</span> StudyHub</a>
            <div class="intro-content">
                <span class="eyebrow">YOUR STUDENT SPACE</span>
                <h1>A little space for big ideas.</h1>
                <p>Sign in to organize your notes, manage your profile, and keep learning.</p>
                <div class="mini-card"><span class="mini-icon">✦</span><span>Learn something new every day.</span></div>
            </div>
            <span class="intro-footer">StudyHub © 2026</span>
        </section>
        <section class="form-panel">
            <div class="form-wrap">
                <span class="mobile-brand">StudyHub</span>
                <span class="eyebrow dark">WELCOME BACK</span>
                <h2>Sign in</h2>
                <p class="subtitle">Enter your details to access your account.</p>
                <?php if (isset($_GET['registered'])): ?>
                    <div class="message success">Account created! You can now sign in.</div>
                <?php endif; ?>
                <?php if ($error !== ''): ?>
                    <div class="message error"><?= escape($error) ?></div>
                <?php endif; ?>
                <form method="post" action="index.php">
                    <input type="hidden" name="token" value="<?= escape(token()) ?>">
                    <label for="email">Email address</label>
                    <input id="email" name="email" type="email" placeholder="you@example.com" autocomplete="email" value="<?= escape($email) ?>" required>
                    <label for="password">Password</label>
                    <input id="password" name="password" type="password" placeholder="Enter your password" autocomplete="current-password" required>
                    <button type="submit" class="primary-btn">Sign in</button>
                </form>
                <p class="form-switch">Don't have an account? <a href="register.php">Create one</a></p>
            </div>
        </section>
    </main>
</body>
</html>
