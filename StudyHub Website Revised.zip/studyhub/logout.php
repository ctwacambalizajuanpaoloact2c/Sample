<?php
require_once __DIR__ . '/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !valid_token()) {
    http_response_code(403);
    exit('Invalid request.');
}
$_SESSION = [];
session_regenerate_id(true);
session_destroy();
redirect('index.php');
