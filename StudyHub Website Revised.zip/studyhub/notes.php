<?php
require_once __DIR__ . '/functions.php';
$user = require_login();
$error = '';
$action = '';
$title = '';
$body = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $id = (string) ($_POST['id'] ?? '');
    $title = trim((string) ($_POST['title'] ?? ''));
    $body = trim((string) ($_POST['body'] ?? ''));

    if (!valid_token()) {
        $error = 'Please refresh the page and try again.';
    } elseif ($action === 'delete') {
        if (remove_note($id, $user['id'])) {
            flash('success', 'Note deleted.');
            redirect('notes.php');
        }
        $error = 'You can only delete your own notes.';
    } elseif ($action === 'create' || $action === 'update') {
        if ($title === '' || strlen($title) > 100) {
            $error = 'Title must be between 1 and 100 characters.';
        } elseif ($body === '' || strlen($body) > 3000) {
            $error = 'Note must be between 1 and 3000 characters.';
        } elseif ($action === 'create') {
            add_note($user['id'], $title, $body);
            flash('success', 'Note created.');
            redirect('notes.php');
        } elseif (edit_note($id, $user['id'], $title, $body)) {
            flash('success', 'Note updated.');
            redirect('notes.php');
        } else {
            $error = 'You can only edit your own notes.';
        }
    } else {
        $error = 'Invalid action.';
    }
}

$notes = my_notes($user['id']);
$selected = null;
$mode = isset($_GET['edit']) ? 'edit' : (isset($_GET['delete']) ? 'delete' : 'create');
$id = (string) ($_GET[$mode] ?? '');
if ($mode !== 'create') {
    foreach ($notes as $note) {
        if ($note['id'] === $id) {
            $selected = $note;
            break;
        }
    }
    if ($selected === null) {
        flash('error', 'Note not found.');
        redirect('notes.php');
    }
}
if ($mode === 'edit' && $error === '') {
    $title = $selected['title'];
    $body = $selected['body'];
}
page_header('My Notes', $user, 'notes');
?>
<main class="dashboard-content wide">
    <span class="eyebrow dark">YOUR WORKSPACE</span>
    <h1>My Notes</h1>
    <p class="subtitle">Create, read, update, and delete your study notes.</p>
    <?php show_flash(); ?>
    <?php if ($error !== ''): ?><div class="message error"><?= escape($error) ?></div><?php endif; ?>

    <section class="account-card form-card">
        <?php if ($mode === 'delete'): ?>
            <h2>Delete note?</h2>
            <p class="muted">Are you sure you want to delete “<?= escape($selected['title']) ?>”?</p>
            <form method="post" action="notes.php">
                <input type="hidden" name="token" value="<?= escape(token()) ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= escape($selected['id']) ?>">
                <div class="inline-actions"><button type="submit" class="danger-btn">Delete note</button><a href="notes.php" class="secondary-btn">Cancel</a></div>
            </form>
        <?php else: ?>
            <h2><?= $mode === 'edit' ? 'Edit note' : 'Add a note' ?></h2>
            <form method="post" action="<?= $mode === 'edit' ? 'notes.php?edit=' . escape($selected['id']) : 'notes.php' ?>">
                <input type="hidden" name="token" value="<?= escape(token()) ?>">
                <input type="hidden" name="action" value="<?= $mode === 'edit' ? 'update' : 'create' ?>">
                <?php if ($mode === 'edit'): ?><input type="hidden" name="id" value="<?= escape($selected['id']) ?>"><?php endif; ?>
                <label for="title">Title</label>
                <input id="title" name="title" type="text" maxlength="100" placeholder="e.g. Today's lesson" value="<?= escape($title) ?>" required>
                <label for="body">Note</label>
                <textarea id="body" name="body" rows="4" maxlength="3000" placeholder="Write something here..." required><?= escape($body) ?></textarea>
                <div class="inline-actions"><button class="small-btn" type="submit"><?= $mode === 'edit' ? 'Save changes' : 'Create note' ?></button><?php if ($mode === 'edit'): ?><a href="notes.php" class="secondary-btn">Cancel</a><?php endif; ?></div>
            </form>
        <?php endif; ?>
    </section>

    <section class="section-space">
        <div class="section-heading"><h2>Saved notes</h2><span class="muted"><?= count($notes) ?> total</span></div>
        <?php if ($notes === []): ?>
            <div class="empty-state">No notes yet. Create your first note above.</div>
        <?php else: ?>
            <div class="notes-grid">
                <?php foreach ($notes as $note): ?>
                    <article class="note-card">
                        <h3><?= escape($note['title']) ?></h3>
                        <p><?= nl2br(escape($note['body'])) ?></p>
                        <span class="meta">Updated <?= escape($note['updated_at']) ?></span>
                        <div class="card-actions"><a class="text-link" href="notes.php?edit=<?= urlencode($note['id']) ?>">Edit</a><a class="delete-link" href="notes.php?delete=<?= urlencode($note['id']) ?>">Delete</a></div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>
<?php page_footer(); ?>
